PRESERVA website
================

FILES
  index.html              Your original single-page site (Home, Rescue Deals, Become a Seller, About)
  contact.html            NEW  Contact Us / development team
  login.html              NEW  Log in
  register.html           NEW  Sign up (Local Buyer, Business Buyer, Seller)
  dashboard-local.html    NEW  Local Buyer dashboard
  dashboard-business.html NEW  Business Buyer dashboard
  dashboard-seller.html   NEW  Seller dashboard
  dashboard-admin.html    NEW  Admin dashboard (restricted)
  style.css               Your stylesheet. Original code untouched; new styles added at the bottom
  script.js               Your original page script. Not changed
  auth.js                 NEW  Accounts, login state, logout, role checks, navbar login links

WHERE TO PUT THE IMAGES (same folder as index.html)
  MJ.png          M Jayross Cruspero
  JR.jpg          Jhun Rey Flores
  Christian.png   Christian Francisco
  Preserva Logo.png, navbar.jpg, footer.png   (your existing images stay where they are)
  File names are case-sensitive on most web hosts: keep them exactly as written above.
  If a team photo is missing, the card shows the person's initials instead.

HOW TO RUN
  Best: run a small local server so every page shares the same browser storage.
    Option 1 (VS Code): install "Live Server", right-click index.html, "Open with Live Server".
    Option 2 (terminal): open this folder in a terminal and run   python -m http.server 8000
                         then visit  http://localhost:8000
  Double-clicking index.html also works in Chrome and Edge, but Firefox keeps separate
  storage for each file, so sign-in will not carry between pages there.

DEMO ADMIN ACCOUNT (created automatically on first run)
  Username: admin      Password: Admin12345
  Change the password in auth.js (CONFIG.ADMIN_SEED), and delete it once real admins exist.
  Admins cannot be created from the Sign up page.

HOW IT WORKS NOW (frontend demo)
  Accounts are saved in the browser's localStorage (keys: preserva_users, preserva_session).
  Clear them any time:  DevTools > Application > Local Storage > Clear.
  Passwords are salted and hashed, never saved as plain text.

MOVING TO A DATABASE LATER
  auth.js has three layers. Replace only the first two when your backend is ready:
    1. usersRepo / storage   -> replace with fetch() calls to your API
    2. PreservaAuth service  -> keep register(), login(), logout(), currentUser(),
                                requireRole(), listUsers(); same inputs and results
    3. Page controllers      -> no changes needed
  On the server: hash passwords with bcrypt or argon2, issue a session cookie or token,
  and check the user's role on every protected request. Browser checks are for the demo only.
