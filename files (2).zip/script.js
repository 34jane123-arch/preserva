// ---------- SETTINGS ----------
// Paste a Formspree URL to receive real seller registrations. Empty = demo mode.
const FORM_ENDPOINT = "";

// DEMO ONLY: first admin account, created in this browser. Change the password, and
// delete this once admin accounts live in your database (anyone can read this file).
const ADMIN_SEED = { name: "PRESERVA Admin", email: "admin@preserva.ph", password: "ChangeMe123" };

// ---------- SAMPLE DATA ----------
// Replace the phone numbers with real seller numbers. until = pickup deadline (24h clock).
const products = [
    { name: "Fresh Pechay", category: "Vegetables", price: 18, oldPrice: 25, unit: "bunch", qty: 12, until: 17, tag: "Sell today",
      seller: "Sample Seller A", phone: "09000000001", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=700&q=80" },
    { name: "Fresh Sayote", category: "Vegetables", price: 25, oldPrice: 35, unit: "kg", qty: 8, until: 18, tag: "Ripe, sell soon",
      seller: "Sample Seller B", phone: "09000000002", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1597362925123-77861d3fbac7?auto=format&fit=crop&w=700&q=80" },
    { name: "Ripe Tomatoes", category: "Vegetables", price: 35, oldPrice: 50, unit: "kg", qty: 10, until: 16, tag: "Very ripe",
      seller: "Sample Seller C", phone: "09000000003", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=700&q=80" },
    { name: "Fresh Carrots", category: "Vegetables", price: 45, oldPrice: 60, unit: "kg", qty: 15, until: 18, tag: "Sell today",
      seller: "Sample Seller A", phone: "09000000001", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1445282768818-728615cc910a?auto=format&fit=crop&w=700&q=80" },
    { name: "Ripe Bananas", category: "Fruits", price: 30, oldPrice: 45, unit: "kg", qty: 20, until: 17, tag: "Very ripe",
      seller: "Sample Seller D", phone: "09000000004", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=700&q=80" },
    { name: "Fresh Mangoes", category: "Fruits", price: 55, oldPrice: 80, unit: "kg", qty: 9, until: 19, tag: "Ripe, sell soon",
      seller: "Sample Seller E", phone: "09000000005", location: "Panabo Central Market",
      image: "https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=700&q=80" }
];

const PRODUCE = [["Pechay","🥬"],["Sayote","🥒"],["Tomatoes","🍅"],["Carrots","🥕"],["Eggplant","🍆"],["Squash","🎃"],["Bananas","🍌"],["Mangoes","🥭"]];

// ---------- HELPERS ----------
const $ = id => document.getElementById(id);
const peso = n => "₱" + n.toLocaleString("en-PH");
const discount = p => Math.round((1 - p.price / p.oldPrice) * 100);
const hourLabel = h => `${((h + 11) % 12) + 1} ${h < 12 ? "AM" : "PM"}`;
const norm = s => String(s).replace(/[\s-]/g, "").replace(/^\+63/, "0");
const phoneOk = v => /^(09|\+639)\d{9}$/.test(v.replace(/[\s-]/g, ""));
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const andList = a => a.length > 1 ? a.slice(0, -1).join(", ") + " and " + a[a.length - 1] : a[0];

function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
}

function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => t.classList.remove("show"), 3200);
}

// Sends a form to FORM_ENDPOINT. Returns "demo" when no endpoint is set.
async function submitTo(form) {
    if (!FORM_ENDPOINT) return "demo";
    const res = await fetch(FORM_ENDPOINT, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(form) });
    if (!res.ok) throw new Error(res.status);
    return "ok";
}


// ---------- MOBILE NAVIGATION ----------
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

function closeMobileNav() {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
}

menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");

    menuToggle.setAttribute("aria-expanded", isOpen);
    menuToggle.textContent = isOpen ? "✕" : "☰";
});

// Close mobile navigation after selecting a link
document.querySelectorAll(".nav-links a").forEach(link => {
    link.addEventListener("click", closeMobileNav);
});


// ---------- ACCOUNTS (stored in this browser until your database is ready) ----------
// Each account: { id, role, ...profile fields, email, salt, passHash, createdAt }.
// Roles: "local" | "business" | "seller" | "admin". Keep this shape when you move to a database.
const load = k => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const users = () => load("preserva_users") || [];
const saveUsers = list => localStorage.setItem("preserva_users", JSON.stringify(list));
const currentUser = () => users().find(u => u.id === localStorage.getItem("preserva_session")) || null;
const randomHex = () => [...crypto.getRandomValues(new Uint8Array(8))].map(b => b.toString(16).padStart(2, "0")).join("");

// Demo-level hashing so passwords aren't stored as plain text. A real database should
// hash on the server with bcrypt or argon2 instead.
async function hashPw(password, salt) {
    const bytes = new TextEncoder().encode(salt + password);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}

async function seedAdmin() {
    if (!window.crypto?.subtle || users().some(u => u.role === "admin")) return;
    const salt = randomHex();
    saveUsers([...users(), {
        id: "admin-" + randomHex(), role: "admin", name: ADMIN_SEED.name, contact: "", address: "",
        email: ADMIN_SEED.email.toLowerCase(), salt, passHash: await hashPw(ADMIN_SEED.password, salt),
        createdAt: new Date().toISOString()
    }]);
}

const FIELD = {
    name:      { label: "Name",       ph: "Enter your Name",       auto: "name" },
    storeName: { label: "Store Name", ph: "Enter your Store Name", auto: "organization" },
    contact:   { label: "Contact",    ph: "Enter your Contact",    auto: "tel", type: "tel" },
    address:   { label: "Address",    ph: "Enter your Address",    auto: "street-address" },
    email:     { label: "Email",      ph: "Enter your Email",      auto: "email", type: "email" },
    password:  { label: "Password",   ph: "Enter your Password",   type: "password" }
};
const BUYER_FIELDS = ["name", "contact", "address", "email", "password"];
const ROLES = {
    local:    { label: "Local Buyer",    fields: BUYER_FIELDS, loginBy: "Contact or Email" },
    business: { label: "Business Buyer", fields: BUYER_FIELDS, loginBy: "Contact or Email" },
    seller:   { label: "Seller",         fields: ["storeName", "contact", "address", "password"], loginBy: "Contact" },
    admin:    { label: "Admin",          fields: [], loginOnly: true, loginBy: "Email" }
};
// The account cards use these names (data-role) in the HTML
const ROLE_KEYS = { "Local Buyer": "local", "Business Buyer": "business", "Seller": "seller", "Admin": "admin" };


// ---------- ACCOUNT MODAL ----------
const modal = document.getElementById("accountModal");
const modalTitle = document.getElementById("modalTitle");
const modalDescription = document.getElementById("modalDescription");

const closeModal = document.getElementById("closeModal");
const loginNav = document.getElementById("loginNav");
const dashNav = document.getElementById("dashNav");

const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");

const accountForm = document.getElementById("accountForm");
const formFields = document.getElementById("formFields");

const submitButton = document.getElementById("submitButton");
const formMessage = document.getElementById("formMessage");

let selectedRole = "Local Buyer";
let currentMode = "login";

function formSay(text, isError) {
    formMessage.textContent = text;
    formMessage.classList.toggle("error", !!isError);
}

function fieldRow(name, label, placeholder, type, autocomplete) {
    const lab = el("label", "", label);
    lab.htmlFor = "auth_" + name;
    const input = el("input");
    Object.assign(input, { id: "auth_" + name, name, type, placeholder, autocomplete });
    const frag = document.createDocumentFragment();
    frag.append(lab, input);
    return frag;
}


// OPEN MODAL
function openModal(role) {
    selectedRole = role;
    const r = ROLES[ROLE_KEYS[role]];

    modalTitle.textContent = role;
    modalDescription.textContent = r.loginOnly
        ? "Log in to manage the platform."
        : `Log in or create your ${role} account.`;

    modal.classList.add("show");
    modal.setAttribute("aria-hidden", "false");

    setMode("login");

    document.body.style.overflow = "hidden";
}


// CLOSE MODAL
function hideModal() {
    modal.classList.remove("show");
    modal.setAttribute("aria-hidden", "true");

    document.body.style.overflow = "";
    accountForm.reset();
    formSay("");
}


// OPEN ACCOUNT CARDS
document.querySelectorAll(".account-card").forEach(card => {
    card.addEventListener("click", () => {
        openModal(card.dataset.role);
    });
});


// OPEN SELLER REGISTRATION
document.querySelectorAll("[data-open-role]").forEach(button => {
    button.addEventListener("click", () => {
        // A seller who is already logged in goes straight to their page
        if (currentUser()?.role === "seller") return enterApp();
        openModal(button.dataset.openRole);
        setMode("register");
    });
});


// LOG IN / LOG OUT BUTTON IN THE NAVIGATION
loginNav.addEventListener("click", () => {
    closeMobileNav();
    if (currentUser()) return logout();
    openModal("Local Buyer");
});

// "MY PAGE" BUTTON IN THE NAVIGATION
dashNav.addEventListener("click", () => {
    closeMobileNav();
    enterApp();
});


// CLOSE BUTTON
closeModal.addEventListener("click", hideModal);


// CLOSE WHEN CLICKING OUTSIDE
modal.addEventListener("click", event => {
    if (event.target === modal) {
        hideModal();
    }
});


// CLOSE WITH ESCAPE
document.addEventListener("keydown", event => {
    if (event.key === "Escape" && modal.classList.contains("show")) {
        hideModal();
    }
});


// SWITCH LOGIN / REGISTER
function setMode(mode) {
    const r = ROLES[ROLE_KEYS[selectedRole]];
    if (r.loginOnly) mode = "login";
    currentMode = mode;

    formSay("");
    registerTab.hidden = !!r.loginOnly;
    loginTab.classList.toggle("active", mode === "login");
    registerTab.classList.toggle("active", mode === "register");
    submitButton.textContent = mode === "register" ? "Create Account" : "Log In";

    formFields.replaceChildren();
    if (mode === "register") {
        r.fields.forEach(k => {
            const f = FIELD[k];
            formFields.append(fieldRow(k, f.label, f.ph, f.type || "text", k === "password" ? "new-password" : f.auto || "off"));
        });
    } else {
        formFields.append(
            fieldRow("login", r.loginBy, `Enter your ${r.loginBy}`, "text", "username"),
            fieldRow("password", "Password", "Enter your Password", "password", "current-password")
        );
    }
}

loginTab.addEventListener("click", () => {
    setMode("login");
});

registerTab.addEventListener("click", () => {
    setMode("register");
});


// LOG IN / CREATE ACCOUNT
accountForm.addEventListener("submit", async event => {
    event.preventDefault();
    formSay("");
    accountForm.querySelectorAll(".field-invalid").forEach(n => n.classList.remove("field-invalid"));

    const fail = (name, text) => {
        const input = accountForm.elements[name];
        input.classList.add("field-invalid");
        input.focus();
        formSay(text, true);
    };
    if (!window.crypto?.subtle) return formSay("Accounts need a secure page. Open the site over https or localhost.", true);

    const d = {};
    new FormData(accountForm).forEach((v, k) => { d[k] = k === "password" ? v : String(v).trim(); });
    const role = ROLE_KEYS[selectedRole];

    if (currentMode === "login") {
        if (!d.login) return fail("login", `Enter your ${ROLES[role].loginBy.toLowerCase()}.`);
        if (!d.password) return fail("password", "Enter your password.");
        const user = users().find(u => u.role === role && (norm(u.contact) === norm(d.login) || u.email === d.login.toLowerCase()));
        const ok = user && await hashPw(d.password, user.salt) === user.passHash;
        if (!ok) return fail("password", "That contact, email, or password doesn't match an account.");
        return finishAuth(user);
    }

    const keys = ROLES[role].fields;
    const missing = keys.find(k => !d[k]);
    if (missing) return fail(missing, `Please enter your ${FIELD[missing].label.toLowerCase()}.`);
    if (!phoneOk(d.contact)) return fail("contact", "Enter a valid mobile number, like 09123456789.");
    if (d.email && !emailOk(d.email)) return fail("email", "Enter a valid email address.");
    if (d.password.length < 8) return fail("password", "Use at least 8 characters for your password.");

    const email = (d.email || "").toLowerCase();
    const all = users();
    if (all.some(u => u.role === role && (norm(u.contact) === norm(d.contact) || (email && u.email === email)))) {
        return fail("contact", "An account with this contact or email already exists. Try logging in.");
    }

    const salt = randomHex();
    const user = { id: Date.now().toString(36) + randomHex(), role, createdAt: new Date().toISOString(), salt, email, passHash: await hashPw(d.password, salt) };
    keys.forEach(k => { if (k !== "password") user[k] = d[k]; });
    saveUsers([...all, user]);
    finishAuth(user);
});

function finishAuth(user) {
    localStorage.setItem("preserva_session", user.id);
    hideModal();
    updateAuthUI();
    toast(`Welcome, ${user.name || user.storeName}!`);
    enterApp();
}

function logout() {
    localStorage.removeItem("preserva_session");
    updateAuthUI();
    leaveApp();
    window.scrollTo({ top: 0 });
    toast("You're logged out.");
}

function updateAuthUI() {
    const u = currentUser();
    loginNav.textContent = u ? "Log out" : "Log in";
    loginNav.title = u ? `Signed in as ${u.name || u.storeName}` : "";
    dashNav.hidden = !u;
}


// ---------- RESCUE DEALS (landing page, local buyer page, business buyer page) ----------
function actionLink(label, href, className, external) {
    const a = el("a", className, label);
    a.href = href;
    if (external) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
    return a;
}

function buildCard(p) {
    const card = el("article", "deal-card");

    const img = el("img");
    img.src = p.image;
    img.alt = p.name;
    img.loading = "lazy";
    img.onerror = () => { img.removeAttribute("src"); img.alt = ""; };

    const info = el("div", "deal-info");
    const priceRow = el("div", "deal-price");
    priceRow.append(el("strong", "", `${peso(p.price)} / ${p.unit}`), el("s", "", peso(p.oldPrice)));

    const meta = el("ul", "deal-meta");
    meta.append(
        el("li", p.qty <= 8 ? "urgent" : "", `${p.qty} ${p.unit === "kg" ? "kg" : "bunches"} left`),
        el("li", "", `Pickup until ${hourLabel(p.until)} today`),
        el("li", "", `${p.seller} · ${p.location}`)
    );

    const mapUrl = "https://www.google.com/maps/search/?api=1&query=" +
        encodeURIComponent(`${p.location}, Panabo City, Davao del Norte`);
    const smsText = encodeURIComponent(`Hi, is the ${p.name} still available on PRESERVA?`);

    const actions = el("div", "deal-actions");
    actions.append(
        actionLink("Call seller", `tel:${p.phone}`, "primary-button"),
        actionLink("Text seller", `sms:${p.phone}?&body=${smsText}`, "outline-button"),
        actionLink("Get directions", mapUrl, "outline-button", true)
    );

    info.append(el("span", "deal-category", p.category), el("h3", "", p.name), priceRow, meta, actions);
    card.append(el("span", "deal-badge", `${discount(p)}% off · ${p.tag}`), img, info);
    return card;
}

// Builds search, sort, category filters and the product grid inside `root`.
// extraSorts lets a page add its own sort option, like { quantity: ["Most produce left", fn] }.
function mountDeals(root, extraSorts = {}) {
    root.replaceChildren();
    let category = "All";

    const search = el("input", "deals-search");
    Object.assign(search, { type: "search", placeholder: "Search produce or sellers" });
    search.setAttribute("aria-label", "Search products");

    const sortLabel = el("label", "deals-sort", "Sort by");
    const select = el("select");
    const sorters = {
        discount: (a, b) => discount(b) - discount(a),
        price: (a, b) => a.price - b.price,
        ending: (a, b) => a.until - b.until
    };
    [["default", "Featured"], ["discount", "Biggest discount"], ["price", "Lowest price"], ["ending", "Ending soonest"]]
        .forEach(([value, text]) => select.append(Object.assign(el("option", "", text), { value })));
    Object.entries(extraSorts).forEach(([value, [text, fn]]) => {
        select.append(Object.assign(el("option", "", text), { value }));
        sorters[value] = fn;
    });
    sortLabel.append(select);

    const toolbar = el("div", "deals-toolbar");
    toolbar.append(search, sortLabel);

    const filters = el("div", "deals-filters");
    ["All", "Vegetables", "Fruits"].forEach(name => {
        const btn = el("button", "deal-filter" + (name === "All" ? " active" : ""), name);
        btn.type = "button";
        btn.setAttribute("aria-pressed", name === "All");
        btn.addEventListener("click", () => {
            category = name;
            filters.querySelectorAll(".deal-filter").forEach(f => {
                f.classList.toggle("active", f === btn);
                f.setAttribute("aria-pressed", f === btn);
            });
            render();
        });
        filters.append(btn);
    });

    const count = el("p", "deals-count");
    count.setAttribute("role", "status");
    const grid = el("div", "deals-grid");

    function render() {
        const term = search.value.toLowerCase().trim();
        const list = products.filter(p =>
            (category === "All" || p.category === category) &&
            [p.name, p.category, p.seller, p.location].join(" ").toLowerCase().includes(term)
        );
        if (sorters[select.value]) list.sort(sorters[select.value]);

        count.textContent = `${list.length} deal${list.length === 1 ? "" : "s"} found`;
        grid.replaceChildren();
        if (!list.length) {
            grid.append(el("p", "deals-empty", "No deals match your search. Try a different word or choose All."));
            return;
        }
        list.forEach(p => grid.append(buildCard(p)));
    }

    search.addEventListener("input", render);
    select.addEventListener("change", render);
    root.append(toolbar, filters, count, grid);
    render();
}

function renderStats(container, items) {
    container.replaceChildren(...items.map(([value, label]) => {
        const box = el("div", "stat-card");
        box.append(el("strong", "", String(value)), el("span", "", label));
        return box;
    }));
}


// ---------- ROLE PAGES (shown after log in) ----------
function enterApp(moveFocus = true) {
    const user = currentUser();
    if (!user) return;

    const viewId = "view-" + user.role;
    document.querySelectorAll(".app-view").forEach(v => { v.hidden = v.id !== viewId; });
    document.body.classList.add("app-mode");
    const who = user.name || user.storeName;

    if (user.role === "local") {
        $("localWelcome").textContent = `Welcome, ${who}`;
        mountDeals($("localDeals"));
    } else if (user.role === "business") {
        $("businessWelcome").textContent = `Welcome, ${who}`;
        const kg = products.filter(p => p.unit === "kg").reduce((s, p) => s + p.qty, 0);
        const saved = products.reduce((s, p) => s + (p.oldPrice - p.price) * p.qty, 0);
        renderStats($("businessStats"), [
            [kg, "kg of produce up for rescue today"],
            [products.length, "deals from local sellers"],
            [peso(saved), "saved by buyers if all sell"]
        ]);
        mountDeals($("businessDeals"), { quantity: ["Most produce left", (a, b) => b.qty - a.qty] });
    } else if (user.role === "seller") {
        $("sellerWelcome").textContent = `Welcome, ${who}`;
        prepareSellerPage(user);
    } else if (user.role === "admin") {
        renderAdmin();
    }

    window.scrollTo({ top: 0 });
    if (moveFocus) $(viewId).querySelector("h2")?.focus({ preventScroll: true });
}

function leaveApp() {
    document.body.classList.remove("app-mode");
    document.querySelectorAll(".app-view").forEach(v => { v.hidden = true; });
}

// Navigation and footer links return to the main page when a role page is open
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", () => {
        if (document.body.classList.contains("app-mode")) leaveApp();
    });
});


// ---------- ADMIN PAGE ----------
function renderAdmin() {
    const list = users().filter(u => u.role !== "admin");
    renderStats($("adminStats"), [["local", "Local buyers"], ["business", "Business buyers"], ["seller", "Sellers"]]
        .map(([role, label]) => [list.filter(u => u.role === role).length, label]));

    const rows = $("adminRows");
    rows.replaceChildren();
    if (!list.length) {
        const tr = el("tr");
        const td = el("td", "empty", "No accounts yet.");
        td.colSpan = 6;
        tr.append(td);
        rows.append(tr);
        return;
    }
    list.forEach(u => {
        const tr = el("tr");
        [u.name || u.storeName, ROLES[u.role]?.label || u.role, u.contact, u.email || "-", u.address,
         new Date(u.createdAt).toLocaleDateString("en-PH")].forEach(v => tr.append(el("td", "", v)));
        rows.append(tr);
    });
}

$("exportUsers").addEventListener("click", () => {
    const data = users().map(({ passHash, salt, ...rest }) => rest);
    const a = el("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    a.download = "preserva-users.json";
    a.click();
    URL.revokeObjectURL(a.href);
});


// ---------- SELLER PAGE: DEAL FORM ----------
const dealForm = $("dealForm");
const dealMessage = $("dealMessage");
const dealSuccess = $("dealSuccess");

$("dealChips").append(...PRODUCE.map(([name, emoji]) => {
    const label = el("label", "chip");
    const input = el("input");
    Object.assign(input, { type: "checkbox", name: "produce", value: name });
    input.dataset.emoji = emoji;
    label.append(input, el("span", "", `${emoji} ${name}`));
    return label;
}));

function setDealMessage(text, isError) {
    dealMessage.textContent = text;
    dealMessage.classList.toggle("error", !!isError);
}

function prepareSellerPage(user) {
    if (!dealForm.businessName.value) dealForm.businessName.value = user.storeName || "";
    if (!dealForm.sellerPhone.value) dealForm.sellerPhone.value = user.contact || "";
    if (!dealForm.sellerLocation.value) dealForm.sellerLocation.value = user.address || "";
    updatePreview();
}

function updatePreview() {
    const chips = [...dealForm.querySelectorAll('input[name="produce"]:checked')];
    const other = dealForm.otherProduce.value.trim();
    const names = chips.map(c => c.value).concat(other ? [other] : []);
    const price = Number(dealForm.price.value);
    const old = Number(dealForm.oldPrice.value);
    const unit = dealForm.unit.value;
    const qty = dealForm.qty.value;
    const hasDeal = price > 0 && old > price;
    const plural = { kg: "kg", bunch: "bunches", piece: "pieces" }[unit];

    $("pvImg").textContent = chips[0]?.dataset.emoji || "🥬";
    $("pvName").textContent = names.length ? names.join(", ") : "Your produce";
    $("pvPrice").textContent = price ? `${peso(price)} / ${unit}` : "Set your price";
    $("pvOld").textContent = hasDeal ? peso(old) : "";
    $("pvBadge").textContent = hasDeal ? `${Math.round((1 - price / old) * 100)}% off · Sell today` : "Sell today";
    $("pvQty").textContent = qty ? `${qty} ${plural} left` : "Quantity left";
    $("pvUntil").textContent = `Pickup until ${hourLabel(Number(dealForm.until.value))} today`;
    $("pvStall").textContent = `${dealForm.businessName.value.trim() || "Your stall"} · ${dealForm.sellerLocation.value.trim() || "Your market"}`;
}
dealForm.addEventListener("input", updatePreview);
dealForm.addEventListener("change", updatePreview);

dealForm.addEventListener("submit", async event => {
    event.preventDefault();
    setDealMessage("");
    dealForm.querySelectorAll(".field-invalid").forEach(f => f.classList.remove("field-invalid"));

    const empty = ["sellerName", "sellerPhone", "businessName", "sellerLocation"].map(n => dealForm[n]).find(f => !f.value.trim());
    if (empty) {
        empty.classList.add("field-invalid");
        empty.focus();
        return setDealMessage("Please fill in your name, number, stall, and location.", true);
    }
    if (!phoneOk(dealForm.sellerPhone.value)) {
        dealForm.sellerPhone.classList.add("field-invalid");
        dealForm.sellerPhone.focus();
        return setDealMessage("Enter a valid mobile number, like 09123456789.", true);
    }
    if (!dealForm.querySelector('input[name="produce"]:checked') && !dealForm.otherProduce.value.trim()) {
        dealForm.querySelector('input[name="produce"]').focus();
        return setDealMessage("Pick at least one kind of produce.", true);
    }
    const price = Number(dealForm.price.value);
    const old = Number(dealForm.oldPrice.value);
    if (price && old && price >= old) {
        dealForm.price.classList.add("field-invalid");
        dealForm.price.focus();
        return setDealMessage("The rescue price should be lower than the usual price.", true);
    }

    const btn = dealForm.querySelector('button[type="submit"]');
    let result;
    btn.disabled = true;
    btn.textContent = "Sending...";
    try {
        result = await submitTo(dealForm);
    } catch {
        return setDealMessage("We couldn't send your registration. Check your connection and try again.", true);
    } finally {
        btn.disabled = false;
        btn.textContent = "Send registration";
    }

    $("successName").textContent = dealForm.sellerName.value.trim();
    $("successNote").textContent = result === "demo" ? "Demo mode: nothing was saved or sent." : "";
    dealForm.hidden = true;
    dealSuccess.hidden = false;
    window.scrollTo({ top: 0 });
});

$("addAnother").addEventListener("click", () => {
    dealForm.reset();
    setDealMessage("");
    dealSuccess.hidden = true;
    dealForm.hidden = false;
    const user = currentUser();
    if (user) prepareSellerPage(user);
    updatePreview();
    dealForm.sellerName.focus();
});


// ---------- START ----------
seedAdmin();
updateAuthUI();
mountDeals($("rescueDeals"));
updatePreview();
if (currentUser()) enterApp(false);
